Star Fox 64 (Rev 1) - Unlocked v1.3

This ROM Hack Unlocks Everything in Star Fox 64 (USA) (Rev 1), adds a Change Course Feature, allows Player 1 to Enable/Disable the Unused Shield and more features. 

Compatibility Confirmed on Everdrive64-X7 / N64 Console / Analogue 3D / Simple64 / RetroArch using Core Nintendo 64 (ParaLLEI N64)

Details:

Alternate Title Screen
30 Medals Across All Planets (Normal and Expert)
Expert Mode Available
Sound Test Available
Landmaster and On-Foot Mode Available in Multiplayer
Change Course Feature 
Unused Shield
Warp Pathways
Hyper Lasers/Smart Bombs/Lives
Repair Ships Wings
Change Engine Colors
Leave Slippy Behind



Change Course Feature Details:
When selecting a planet on the map screen, Press Start on your N64 controller. This will bring up the option to select an alternate course of your choice, even if you failed to complete the prior level’s secret mission(s). The following levels do not have secret missions/alternate routes, you only need to survive: Aquas, Solar, and Titania. 
Please note: If you are playing on v1.1 or v1.2 hold L while selecting the next planet, and then push A to bring up the Change Course option.

Unused Shield Details:
Press D-Pad Up to enable and D-Pad Down to disable the unused shield. With the unused shield enabled, your Arwing will not take any damage from objects or enemy fire. The Arwing can still take damage from the heat on Solar, and can still lose its wing(s) if inhaled by Andross. The Landmaster, Blue-Marine, and On-Foot will also be invincible while the shield is active. The shield is only visible with the Arwing, and can only be used by Player 1. 

Warp Pathways Details:
Meteo and Sector X are the only two levels in the game that have Warp Zones. If you complete the levels normally but would still like to warp to their alternate courses, hold L on your N64 controller while selecting the next planet, and then push A. This will bring up the option to Change Course and warp to Katina from Meteo, and Sector Z from Sector X. If you wish to go to Macbeth from Sector X, simply Press Start on your N64 controller while Titania is highlighted. 

Hyper Lasers/Smart Bombs/Lives Details:
Press D-Pad Left to activate Hyper Lasers, refill Smart Bombs to Max (9), and fill your lives to 99. (This addition was inspired by Easy Mode in the recently announced Star Fox for Switch 2)

Repair Ships Wings Details:
In the event that your ship's wings break off, simply Press D-Pad Right to repair one or both wings. 

Change Engine Colors Details:
Press D-Pad Up to activate Green, D-Pad Right to activate Red, D-Pad Down to activate Orange, and D-Pad Left to activate Blue.

Leave Slippy Behind Details:
During the second half of the boss fight on Sector X, Slippy will fly in to handle the situation. If you do not intervene, Slippy will be struck by the boss and crash on Titania. After you complete the level you can then either warp to Sector Z (Hold L while selecting Titania), or Change Course to Macbeth (Press Start). As a result, Slip will be left behind and will not respawn for subsequent missions. Unfortunately, his dialogue will still play during boss fights, but he will not be present in the level themselves, nor display the enemy bosses health.


Upload a copy of your ROM to confirm you have the correct version for this patch via the following link: https://www.romhacking.net/hash/

Convert your ROM from .n64/.v64 to the required format of .z64 via the following link: https://hack64.net/tools/swapper.php

Patch your copy of Star Fox 64 (USA) (Rev 1) ROM with the included Floating IPS File (.bps) via the following link: https://www.romhacking.net/patch/ 

ROM / ISO Information:
Database match: Star Fox 64 (USA) (Rev 1)
Database: No-Intro: Nintendo 64 (v. 20210220-053642)
File/ROM SHA-1: 09F0D105F476B00EFA5303A3EBC42E60A7753B7A
File/ROM CRC32: B1B5FC46