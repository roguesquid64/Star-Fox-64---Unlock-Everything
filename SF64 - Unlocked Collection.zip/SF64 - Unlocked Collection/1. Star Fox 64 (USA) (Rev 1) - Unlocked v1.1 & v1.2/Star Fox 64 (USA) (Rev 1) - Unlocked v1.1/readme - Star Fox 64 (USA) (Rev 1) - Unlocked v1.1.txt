Star Fox 64 (USA) (Rev 1) - Unlocked v1.1

This ROM Hack Unlocks Everything in Star Fox 64 (USA) (Rev 1), and adds a Change Course Feature.

Compatibility Confirmed on Everdrive64-X7 / N64 Console / Analogue 3D / Simple64 / RetroArch using Core Nintendo 64 (ParaLLEI N64)

Details:

Alternate Title Screen
30 Medals Across All Planets (Normal and Expert)
Expert Mode Available
Sound Test Available
Landmaster and On-Foot Mode Available in Multiplayer
Change Course Feature


Change Course Feature Details:
When selecting a planet on the map screen, hold L on your N64 controller, then push A. This will bring up the option to select an alternate course of your choice, even if you failed to complete the prior level’s secret mission(s). The following levels do not have secret missions/alternate routes, you only need to survive: Aquas, Solar, and Titania


Upload a copy of your ROM to confirm you have the correct version for this patch via the following link: https://www.romhacking.net/hash/

Convert your ROM from .n64/.v64 to the required format of .z64 via the following link: https://hack64.net/tools/swapper.php

Patch your copy of Star Fox 64 (USA) (Rev 1) ROM with the included Floating IPS File (.bps) via the following link: https://www.romhacking.net/patch/ 

ROM / ISO Information:
Database match: Star Fox 64 (USA) (Rev 1)
Database: No-Intro: Nintendo 64 (v. 20210220-053642)
File/ROM SHA-1: 09F0D105F476B00EFA5303A3EBC42E60A7753B7A
File/ROM CRC32: B1B5FC46