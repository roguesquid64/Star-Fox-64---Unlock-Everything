Lylat Wars (Europe) (En,Fr,De) - Unlocked

This ROM Hack Unlocks Everything in Lylat Wars (Europe) (En,Fr,De).

Compatibility Confirmed on Everdrive64-X7 / N64 Console / Analogue 3D / Simple64 / RetroArch using Core Nintendo 64 (ParaLLEI N64)

Details:

Alternate Title Screen
30 Medals Across All Planets (Normal and Expert)
Expert Mode Available
Sound Test Available
Landmaster and On-Foot Mode Available in Multiplayer


Upload a copy of your ROM to confirm you have the correct version for this patch via the following link: https://www.romhacking.net/hash/

Convert your ROM from .n64/.v64 to the required format of .z64 via the following link: https://hack64.net/tools/swapper.php

Patch your copy of Lylat Wars (Europe) (En,Fr,De) ROM with the included Floating IPS File (.bps) via the following link: https://www.romhacking.net/patch/ 

ROM / ISO Information:
Database match: Lylatwars (Europe) (En,Fr,De)
Database: No-Intro: Nintendo 64 (v. 20210220-053642)
File/ROM SHA-1: 05B307B8804F992AF1A1E2FBAFBD588501FDF799
File/ROM CRC32: 50A9C0B1